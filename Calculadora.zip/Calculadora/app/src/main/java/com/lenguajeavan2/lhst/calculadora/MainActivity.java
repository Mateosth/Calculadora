package com.lenguajeavan2.lhst.calculadora;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.lenguajeavan2.lhst.calculadora.R.id.txtusuario;

public class MainActivity extends AppCompatActivity {

    // Button boton;
    EditText txtusuario1;
    EditText txtclave1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button boton=(Button) findViewById(R.id.btnboton);

        boton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String usuario=((EditText) findViewById(txtusuario)).getText().toString();//Capturo el valor de txtusuario y lo convierto a string
                String clave=((EditText) findViewById(R.id.txtclave)).getText().toString();//Capturo el valor de txtclave y lo convierto a string
                txtusuario1=((EditText) findViewById(txtusuario));//Capturo el valor de txtusuario y lo convierto a string
                txtclave1=((EditText) findViewById(R.id.txtclave));//Capturo el valor de txtclave y lo convierto a string

                if(usuario.equals("")){
                    Toast.makeText(getApplicationContext(),"Por Favor Ingrese un Usuario",Toast.LENGTH_SHORT).show();

                }
                else{
                    if(clave.equals("")){
                        Toast.makeText(getApplicationContext(),"Por Favor Ingrese una Clave",Toast.LENGTH_SHORT).show();

                    }
                    else{


                        if (usuario.equals("administrador")&& clave.equals("Horus17")){//Se compara si la clave y el usuario son los entrados en las cajas de texto
                            Intent nuevoformulario=new Intent(MainActivity.this,Ventana2.class);
                            startActivity(nuevoformulario);
                            txtusuario1.setText("");
                            txtclave1.setText("");



                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Datos Incorrectos",Toast.LENGTH_SHORT).show();
                            txtusuario1.setText("");
                            txtclave1.setText("");


                        }

                    }



                }
            }  }
        );
    }
    public void Borrar(View view) {
        txtusuario1=((EditText) findViewById(txtusuario));//Capturo el valor de txtusuario y lo convierto a string
        txtclave1=((EditText) findViewById(R.id.txtclave));//Capturo el valor de txtclave y lo convierto a string
        txtusuario1.setText("");
        txtclave1.setText("");

    }
    public void Volver(View view) {
        Intent MiIntent=new Intent(MainActivity.this,Ventana2.class);
        startActivity(MiIntent);

    }
}

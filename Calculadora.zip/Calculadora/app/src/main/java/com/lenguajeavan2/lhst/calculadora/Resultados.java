package com.lenguajeavan2.lhst.calculadora;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Resultados extends AppCompatActivity {

    TextView r_suma,r_resta,r_multi,r_divi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);
        r_suma = (TextView) findViewById( R.id.r_suma );
        r_resta = (TextView) findViewById( R.id.r_resta );
        r_multi = (TextView) findViewById( R.id.r_multi);
        r_divi = (TextView) findViewById( R.id.r_divi );



        Intent intent=getIntent();
        Bundle extras =intent.getExtras();
        if (extras != null) {//ver si contiene datos
            String resultSuma=(String)extras.get("sumart");//Obtengo el resultado
            String resultResta= (String) extras.get("restart");//Obtengo el resultado
            String resultMulti=(String)extras.get("multirt");//Obtengo el resultado
            String resultDivi= (String) extras.get("divirt");//Obtengo el resultado

            r_suma.setText(resultSuma);
            r_resta.setText(resultResta);
            r_multi.setText(resultMulti);
            r_divi.setText(resultDivi);
        }
    }


    public void Volver1(View view) {
        Intent MiIntent1=new Intent(Resultados.this,Ventana2.class);
        startActivity(MiIntent1);

    }




}

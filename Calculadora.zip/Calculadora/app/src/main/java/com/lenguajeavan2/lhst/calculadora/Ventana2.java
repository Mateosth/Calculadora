package com.lenguajeavan2.lhst.calculadora;

import android.content.Intent;
import android.support.v4.util.TimeUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import static com.lenguajeavan2.lhst.calculadora.R.id.btnEjecutar;
import static com.lenguajeavan2.lhst.calculadora.R.id.txtusuario;

public class Ventana2 extends AppCompatActivity implements View.OnClickListener {
    //Casteando valores
    EditText txtN1,txtN2,txtRsuma,txtRresta,txtRmulti,txtRdivi;//Variables de las cajas de texto
    RadioButton rbSuma,rbResta,rbMulti,rbDivi;//Variables de los radio buttons
    Button btnEnviar,btEjecutar;
    RadioGroup radioGr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana2);
        txtN1=(EditText) findViewById(R.id.txtN1);
        txtN2=(EditText) findViewById(R.id.txtN2);
        txtRsuma=(EditText) findViewById(R.id.txtRsuma);
        txtRresta=(EditText) findViewById(R.id.txtRresta);
        txtRmulti=(EditText) findViewById(R.id.txtRmulti);
        txtRdivi=(EditText) findViewById(R.id.txtRdivi);

        rbSuma=(RadioButton) findViewById(R.id.rbtSuma);
        rbResta=(RadioButton) findViewById(R.id.rbtResta);
        rbMulti=(RadioButton) findViewById(R.id.rbtMulti);
        rbDivi=(RadioButton) findViewById(R.id.rbtDivi);
        btnEnviar=(Button)findViewById(R.id.btnResultado);
       // btEjecutar=(Button)findViewById(R.id.btnEjecutar);
        radioGr = (RadioGroup) findViewById(R.id.RadioGroup);

        btnEnviar.setOnClickListener(this);
        //btEjecutar.setOnClickListener(this);

   }
    public void onClick(View view) {
if((txtRsuma.getText().toString().isEmpty())|| (txtRresta.getText().toString().isEmpty())||(txtRmulti.getText().toString().isEmpty())||(txtRdivi.getText().toString().isEmpty())){
    Toast.makeText(getApplicationContext(),"POR FAVOR REALIZAR TODAS LAS OPERACIONES MATEMÁTICAS",Toast.LENGTH_SHORT).show();


}else{
        Intent explicit_intent;//Declaro el Intent

        //Instanciamos el Intent dandole:
        // el contexto y la clase a la cual nos deseamos dirigir
        explicit_intent = new Intent(this,Resultados.class);
        String rtSuma=txtRsuma.getText().toString();
        String rtResta=txtRresta.getText().toString();
        String rtMulti=txtRmulti.getText().toString();
        String rtDivi=txtRdivi.getText().toString();


        explicit_intent.putExtra("sumart",rtSuma);//Guardamos una cadena
        explicit_intent.putExtra("restart",rtResta);//Guardamos una cadena
        explicit_intent.putExtra("multirt",rtMulti);//Guardamos una cadena
        explicit_intent.putExtra("divirt",rtDivi);//Guardamos una cadena



        //lo iniciamos pasandole la intencion, con todos sus parametros guardados
        startActivity(explicit_intent);
    }

    }





    //Validando que los edit Text no vengan vacios y el radio button seleccionado

public void Ejecutar(View view){
    String val1=txtN1.getText().toString().trim();//variable captura el valor de la caja de texto y elimina los espacios vacios
    String val2=txtN2.getText().toString().trim();//variable captura el valor de la caja de texto y elimina los espacios vacios
    String valor1=txtN1.getText().toString();
    String valor2=txtN2.getText().toString();
    int n1=Integer.parseInt(valor1);//Para operaciones
    int n2=Integer.parseInt(valor2);//Para operaciones


   // if((txtN1.getText().toString().isEmpty())|| (txtN2.getText().toString().isEmpty())){
       // Toast.makeText(getApplicationContext(),"POR FAVOR LLENAR TODOS LOS CAMPOS",Toast.LENGTH_SHORT).show();

   if (TextUtils.isEmpty(val1)|| (val1==null) ){//Para verificar si las cajas de texto están vacias
        txtN1.setError("Ingresar un número");//Si está vacía avisa para ingresar un número
//txtN1.requestFocus();//Ubicando en el control donde se equivoca el usuario
    }
    else if  (TextUtils.isEmpty(val2)|| (val2==null)){

       //Para verificar si las cajas de texto están vacias
      txtN2.setError("Ingresar un número");//Si está vacía avisa para ingresar un número
       // txtN2.requestFocus();//Ubicando en el control donde se equivoca el usuario

    }



    switch(radioGr.getCheckedRadioButtonId())



    {
        case R.id.rbtSuma:
            int suma=n1+n2;
            String cadena1= Integer.toString(suma);
            txtRsuma.setText(cadena1);
            Toast.makeText(getApplicationContext(),"LA SUMA ES : "+suma,Toast.LENGTH_SHORT).show(); break;
        case R.id.rbtResta:
            int resta=n1-n2;
            String cadena2= Integer.toString(resta);
            txtRresta.setText(cadena2);
            Toast.makeText(getApplicationContext(),"LA RESTA ES : "+resta,Toast.LENGTH_SHORT).show(); break;
        case R.id.rbtMulti:
            int multiplicacion=n1*n2;
            String cadena3= Integer.toString(multiplicacion);
            txtRmulti.setText(cadena3);
            Toast.makeText(getApplicationContext(),"LA MULTIPLICACIÓN ES : "+multiplicacion,Toast.LENGTH_SHORT).show(); break;

        default: if((n1==0) || (n2==0)){
            Toast.makeText(getApplicationContext(),"LOS VALORES DEBEN SER DIFERENTES A CERO PARA REALIZAR LA DIVISÓN ",Toast.LENGTH_SHORT).show();
        }

        else {

            int division=n1/n2;
            String cadena4= Integer.toString(division);
            txtRdivi.setText(cadena4);
            Toast.makeText(getApplicationContext(),"LA DIVISIÓN ES : "+division,Toast.LENGTH_SHORT).show();
        }
    }



}







 public void Volver(View view) {
 Intent MiIntent=new Intent(Ventana2.this,MainActivity.class);
        startActivity(MiIntent);

    }



}


